<?php
/**
 * https://support.google.com/adsense/answer/4455881
 * https://support.google.com/adsense/answer/1705822
 */
global $global;
require_once $global['systemRootPath'] . 'plugin/Plugin.abstract.php';

class GoogleAds_IMA extends PluginAbstract {

    private $script = 'panorama';

    public function getDescription() {
        return "IMA SDK Plugin to enable advertising on your video content.";
    }

    public function getName() {
        return "GoogleAds_IMA";
    }

    public function getUUID() {
        return "32202345-43a9-479b-994a-5430dc22958c";
    }
    
    
    public function getEmptyDataObject() {
        $obj = new stdClass();
        //$obj->adTagUrl = 'http://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/124319096/external/ad_rule_samples&ciu_szs=300x250&ad_rule=1&impl=s&gdfp_req=1&env=vp&output=xml_vmap1&unviewed_position_start=1&cust_params=sample_ar%3Dpremidpostpod%26deployment%3Dgmf-js&cmsid=496&vid=short_onecue&correlator=';
        $obj->adTagUrl = 'https://googleads.g.doubleclick.net/pagead/ads?ad_type=video&client=ca-video-pub-4968145218643279&videoad_start_delay=0&description_url=http%3A%2F%2Fwww.google.com&max_ad_duration=40000&adtest=on';
        return $obj;
    }

    public function getHeadCode() {
        global $global;
        $js = '<script src="//imasdk.googleapis.com/js/sdkloader/ima3.js"></script>';
        $css = '';
        $css .= '<link href="' . $global['webSiteRootURL'] . 'plugin/GoogleAds_IMA/videojs-ima/videojs.ima.css" rel="stylesheet" type="text/css"/>';
        $css .= '<style></style>';
        return $js.$css;
    }

    public function getFooterCode() {
        global $global;
        $obj = $this->getDataObject();
        $js = '<script src="' . $global['webSiteRootURL'] . 'plugin/GoogleAds_IMA/videojs-ima/videojs.ima.js" type="text/javascript"></script>';
        $js .= "<script>


$(function () {
    player = videojs('mainVideo');
    var options = {
        id: 'mainVideo',
        adTagUrl: '{$obj->adTagUrl}'
    };
    player.ima(options);
    // Remove controls from the player on iPad to stop native controls from stealing
    // our click
    var contentPlayer = document.getElementById('content_video_html5_api');
    if ((navigator.userAgent.match(/iPad/i) ||
            navigator.userAgent.match(/Android/i)) &&
            contentPlayer.hasAttribute('controls')) {
        contentPlayer.removeAttribute('controls');
    }

    // Initialize the ad container when the video player is clicked, but only the
    // first time it's clicked.
    var startEvent = 'click';
    if (navigator.userAgent.match(/iPhone/i) ||
            navigator.userAgent.match(/iPad/i) ||
            navigator.userAgent.match(/Android/i)) {
        startEvent = 'touchend';
    }
    player.one(startEvent, function () {
        player.ima.initializeAdDisplayContainer();
    });
});
</script>";
        return $js;
    }

}
