<?php
require_once '../../videos/configuration.php';
?>
<html>
    <head>
        <title>Video.js Test</title>
        <link rel="stylesheet" href="../style.css" />
        <link rel="stylesheet" href="../../node_modules/video.js/dist/video-js.min.css">
        <link rel="stylesheet" href="../../node_modules/videojs-contrib-ads/dist/videojs.ads.css" />
        <link rel="stylesheet" href="../../dist/videojs.ima.css" />



        <link href="<?php echo $global['webSiteRootURL']; ?>js/video.js/video-js.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $global['webSiteRootURL']; ?>js/videojs-contrib-ads/videojs.ads.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo $global['webSiteRootURL']; ?>plugin/GoogleAds_IMA/videojs-ima/videojs.ima.css" rel="stylesheet" type="text/css"/>

    </head>

    <body>
        <video id="content_video" class="video-js vjs-default-skin"
               poster = "" controls preload="auto" width="640"
               height="360">
            <source src="http://rmcdn.2mdn.net/Demo/vast_inspector/android.mp4"
                    type="video/mp4" ></source>
        </video>

        <script src="//imasdk.googleapis.com/js/sdkloader/ima3.js"></script>
        <script src="<?php echo $global['webSiteRootURL']; ?>js/video.js/video.js" type="text/javascript"></script>
        <script src="<?php echo $global['webSiteRootURL']; ?>js/videojs-contrib-ads/videojs.ads.min.js" type="text/javascript"></script>
        <script src="<?php echo $global['webSiteRootURL']; ?>plugin/GoogleAds_IMA/videojs-ima/videojs.ima.js" type="text/javascript"></script>

        <script>
            /**
             * Copyright 2014 Google Inc.
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *     http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */

            var player = videojs('content_video');

            var options = {
                id: 'content_video',
                adTagUrl: 'http://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/124319096/external/ad_rule_samples&ciu_szs=300x250&ad_rule=1&impl=s&gdfp_req=1&env=vp&output=xml_vmap1&unviewed_position_start=1&cust_params=sample_ar%3Dpremidpostpod%26deployment%3Dgmf-js&cmsid=496&vid=short_onecue&correlator='
            };

            player.ima(options);

            // Remove controls from the player on iPad to stop native controls from stealing
            // our click
            var contentPlayer = document.getElementById('content_video_html5_api');
            if ((navigator.userAgent.match(/iPad/i) ||
                    navigator.userAgent.match(/Android/i)) &&
                    contentPlayer.hasAttribute('controls')) {
                contentPlayer.removeAttribute('controls');
            }

            // Initialize the ad container when the video player is clicked, but only the
            // first time it's clicked.
            var startEvent = 'click';
            if (navigator.userAgent.match(/iPhone/i) ||
                    navigator.userAgent.match(/iPad/i) ||
                    navigator.userAgent.match(/Android/i)) {
                startEvent = 'touchend';
            }
            player.one(startEvent, function () {
                player.ima.initializeAdDisplayContainer();
            });
        </script>

    </body>
</html>
